const tab_home = require('./tab_home.png')
const tab_home_selected = require('./tab_home_selected.png')

export default {
  tab_home,
  tab_home_selected,
}
