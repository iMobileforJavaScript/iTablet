import publicAssets from './public'
import tabBar from './tabBar'
import friend from './friend'

export default {
  publicAssets,
  tabBar,
  friend,
}
