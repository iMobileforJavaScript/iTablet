import graphColorScheme from './graphColorScheme'

export default {
  graphColorScheme,
}
