const CA_Red_Rose = require('./CA_Red_Rose.png')
const CB_Childish = require('./CB_Childish.png')
const CC_Blue_Yellow = require('./CC_Blue_Yellow.png')
const CD_Concise = require('./CD_Concise.png')
const CE_Reposeful = require('./CE_Reposeful.png')
const CF_Home = require('./CF_Home.png')
const CG_Cold = require('./CG_Cold.png')
const CH_Naive = require('./CH_Naive.png')
const DA_Limber = require('./DA_Limber.png')
const DB_Field = require('./DB_Field.png')
const DC_Dressy = require('./DC_Dressy.png')
const DD_Set = require('./DD_Set.png')
const DE_Shock = require('./DE_Shock.png')
const DF_Summer = require('./DF_Summer.png')
const DG_Common = require('./DG_Common.png')
const DH_Red_Blue = require('./DH_Red_Blue.png')
const EA_Orange = require('./EA_Orange.png')
const EB_Cold = require('./EB_Cold.png')
const EC_Distinct = require('./EC_Distinct.png')
const ED_Pastal = require('./ED_Pastal.png')
const EE_Grass = require('./EE_Grass.png')
const EF_Blind = require('./EF_Blind.png')
const EG_Passion = require('./EG_Passion.png')
const EH_Amazing = require('./EH_Amazing.png')
const HA_Calm = require('./HA_Calm.png')
const HB_Distance = require('./HB_Distance.png')
const HC_Exotic = require('./HC_Exotic.png')
const HD_Luck = require('./HD_Luck.png')
const HE_Moist = require('./HE_Moist.png')
const HF_Warm = require('./HF_Warm.png')

export default {
  CA_Red_Rose,
  CB_Childish,
  CC_Blue_Yellow,
  CD_Concise,
  CE_Reposeful,
  CF_Home,
  CG_Cold,
  CH_Naive,
  DA_Limber,
  DB_Field,
  DC_Dressy,
  DD_Set,
  DE_Shock,
  DF_Summer,
  DG_Common,
  DH_Red_Blue,
  EA_Orange,
  EB_Cold,
  EC_Distinct,
  ED_Pastal,
  EE_Grass,
  EF_Blind,
  EG_Passion,
  EH_Amazing,
  HA_Calm,
  HB_Distance,
  HC_Exotic,
  HD_Luck,
  HE_Moist,
  HF_Warm,
}
