// import publicAssets from './public'
// import tabBar from './tabBar'
import attribute from './attribute'
import common from './common'
import theme from './theme'
import mapTools from './mapTools'

export default {
  // publicAssets,
  // tabBar,
  attribute,
  common,
  theme,
  mapTools,
}
