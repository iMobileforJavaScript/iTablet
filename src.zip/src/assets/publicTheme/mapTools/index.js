const tools_rectangle_cut = require('./tools_rectangle_cut.png')

export default {
  tools_rectangle_cut,
}
