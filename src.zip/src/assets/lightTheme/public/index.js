const icon_undo = require('./icon_undo_light.png')
const icon_redo = require('./icon_redo_light.png')
const icon_revert = require('./icon_revert_light.png')
const list_section_packup = require('./list_section_packup.png')
const list_section_spread = require('./list_section_spread.png')
const icon_arrow_right = require('./icon_arrow_right_light.png')

export default {
  icon_undo,
  icon_redo,
  icon_revert,
  list_section_packup,
  list_section_spread,
  icon_arrow_right,
}
