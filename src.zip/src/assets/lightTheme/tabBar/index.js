const tab_home = require('./tab_home.png')
const tab_home_selected = require('./tab_home_selected.png')
const tab_friend = require('./tab_friend.png')
const tab_friend_selected = require('./tab_friend_selected.png')
export default {
  tab_home,
  tab_home_selected,
  tab_friend,
  tab_friend_selected,
}
