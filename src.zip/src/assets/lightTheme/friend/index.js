const friend_add = require('./app_friend_add.png')
const friend_search = require('./app_friend_search.png')

export default {
  friend_add,
  friend_search,
}
