const attribute_statistics = require('./attribute_statistics.png')
const attribute_location = require('./attribute_location.png')
const rightbar_tool_select_layerlist = require('./rightbar_tool_select_layerlist_50.png')
const icon_attribute_browse = require('./icon_attribute_browse_light.png')

export default {
  attribute_statistics,
  attribute_location,
  rightbar_tool_select_layerlist,
  icon_attribute_browse,
}
