const icon_collection_change = require('./icon_collection_change.png')

export default {
  icon_collection_change,
}
