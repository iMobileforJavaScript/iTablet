import HorizontalTableList from './HorizontalTableList'

export default HorizontalTableList
