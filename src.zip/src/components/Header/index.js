import Header from './Header'
// import { connect } from 'react-redux'

// export default connect(({ nav }) => ({
//   nav,
// }))(Header)

export default Header
