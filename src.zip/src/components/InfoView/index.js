import InfoView from './InfoView'

export default InfoView
