import PanAudioButton from './PanAudioButton'

export default PanAudioButton
