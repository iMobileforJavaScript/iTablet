import PopModal from './PopModal'

export default PopModal
