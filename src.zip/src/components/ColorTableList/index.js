import ColorTableList from './ColorTableList'

export default ColorTableList
