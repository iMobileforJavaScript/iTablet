import { StyleSheet } from 'react-native'
import { scaleSize } from '../../utils'

export default StyleSheet.create({
  container: {
    width: '100%',
    height: scaleSize(8),
    // backgroundColor: 'black',
  },
})
