import SaveMapNameDialog from './SaveMapNameDialog'

export default SaveMapNameDialog
