import FlowTable from './FlowTable'

export default FlowTable
