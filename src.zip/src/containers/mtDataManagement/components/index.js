import DataManagerTab from './DataManagerTab'

export {
  DataManagerTab,
}