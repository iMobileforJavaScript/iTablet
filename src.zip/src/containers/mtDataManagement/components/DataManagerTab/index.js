import DataManagerTab from './DataManagerTab'

export default DataManagerTab