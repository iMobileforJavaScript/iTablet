import AlertDialog from './alertDialog'

export default AlertDialog
