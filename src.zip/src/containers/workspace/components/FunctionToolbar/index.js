import FunctionToolbar from './FunctionToolbar'
// import { connect } from 'react-redux'
// const mapStateToProps = state => ({
//     language: state.setting.toJS().language
//   })
  
//   const mapDispatchToProps = {}
//   export default connect(
//     mapStateToProps,
//     mapDispatchToProps,
//   )(FunctionToolbar)

  export default FunctionToolbar
