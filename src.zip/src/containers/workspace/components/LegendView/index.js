import LegendView from './LegendView'

export default LegendView
