import CollectionToolbar from './CollectionToolbar'

export default CollectionToolbar
