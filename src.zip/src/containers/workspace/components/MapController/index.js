import MapController from './MapController'

export default MapController
