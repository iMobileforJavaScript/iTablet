import { StyleSheet } from 'react-native'
export default StyleSheet.create({
  container: {
    backgroundColor: '#F0F0F0',
  },
})
