import React, { Component } from 'react'
import { View } from 'react-native'

export default class MultiBufferAnalystView extends Component {
  props: {
    navigation: Object,
    data: Array,
  }

  constructor(props) {
    super(props)
    this.state = {}
  }

  render() {
    return <View />
  }
}
