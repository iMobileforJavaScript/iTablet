import { connect } from 'react-redux'
import CloudService from './CloudService'

const mapStateToProps = () => ({})

const mapDispatchToProps = {}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CloudService)
