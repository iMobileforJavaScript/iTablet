export default {
  // MSG_IP:  '192.168.0.111',
  // MSG_Port:  5672,
  // MSG_HostName: '/',
  // MSG_UserName: 'androidtest',
  // MSG_Password: 'androidtest',
  MSG_IP: '111.202.121.144',
  MSG_Port: 5672,
  MSG_HostName: '/',
  MSG_UserName: 'admin',
  MSG_Password: 'admin',
}
