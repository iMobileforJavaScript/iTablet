import MTDataCollection from './MT_dataCollection'

export default MTDataCollection
