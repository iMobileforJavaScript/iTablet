import ColorPickerPage from './ColorPickerPage'

export default ColorPickerPage
