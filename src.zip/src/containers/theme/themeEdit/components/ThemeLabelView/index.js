import ThemeLabelView from './ThemeLabelView'

export default ThemeLabelView