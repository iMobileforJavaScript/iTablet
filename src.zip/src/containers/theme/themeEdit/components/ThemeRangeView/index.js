import ThemeRangeView from './ThemeRangeView'

export default ThemeRangeView