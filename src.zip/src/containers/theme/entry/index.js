import ThemeEntry from './ThemeEntry'

export default ThemeEntry