import ChoosePage from './ChoosePage'

export default ChoosePage