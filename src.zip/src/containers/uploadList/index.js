import UpLoadList from './uploadList'

export default UpLoadList