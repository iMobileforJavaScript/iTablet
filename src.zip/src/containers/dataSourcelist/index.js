import dataSourcelist from './dataSourcelist'

export default dataSourcelist
