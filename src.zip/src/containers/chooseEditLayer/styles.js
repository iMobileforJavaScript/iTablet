import { StyleSheet } from 'react-native'
import * as Util from '../../utils/constUtil'

export default StyleSheet.create({
  container: {
    flex: 1,
    // alignItems: 'center',
    // justifyContent: 'center',
    backgroundColor:Util.USUAL_GREEN,
  },
})