import LocationModal from './LocationView'

export default LocationModal
