import LayerAttributeTable from './LayerAttributeTable'

export default LayerAttributeTable
