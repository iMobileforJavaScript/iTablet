import LayerManager_tab from './LayerAttributeTab'

export default LayerManager_tab