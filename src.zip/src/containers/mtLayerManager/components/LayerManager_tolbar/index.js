import LayerManager_tolbar from './LayerManager_tolbar'
// import { connect } from 'react-redux'

// const mapStateToProps = state => ({
//   language: state.setting.toJS().language,
// })

// const mapDispatchToProps = {
// }
// export default connect(
//   mapStateToProps,
//   mapDispatchToProps,
// )(LayerManager_tolbar)


export default LayerManager_tolbar
