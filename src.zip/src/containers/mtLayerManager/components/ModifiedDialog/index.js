import ModifiedDialog from './ModifiedDialog'

export default ModifiedDialog
