import LayerManager_tab from './LayerManager_tab'

export default LayerManager_tab