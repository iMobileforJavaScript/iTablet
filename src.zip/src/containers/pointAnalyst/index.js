import PointAnalyst from './pointAnalyst'
export default PointAnalyst
