import AnalystParams from './Analyst_params'

export default AnalystParams