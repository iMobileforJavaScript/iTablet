/*
  Copyright © SuperMap. All rights reserved.
  Author: Wang zihao
  E-mail: zihaowang5325@qq.com
*/

import * as React from 'react'
import { View, Text } from 'react-native'
import styles from './styles'

export default class Analyst_params extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <Text>analyst</Text>
      </View>
    )
  }
}
