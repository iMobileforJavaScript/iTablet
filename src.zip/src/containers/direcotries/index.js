import Directories from './Directories'

export default Directories
