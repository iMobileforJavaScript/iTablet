/**
 * 分析常量
 */
export default {
  BUFFER_ANALYST: '缓冲分析',
  OVERLAY_ANALYST: '叠加分析',
}
