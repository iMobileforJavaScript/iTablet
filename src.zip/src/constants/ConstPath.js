const AppPath = '/iTablet/'
const Data = 'Data/'
const DefaultData = 'DefaultData/'
const Collection = 'Collection'
const MapEdit = 'MapEdit'
const MapTheme = 'Map/MapTheme'
const Workspace = 'Workspace.sxwu' // 工作空间
const Plotting = 'Plotting'
const Module = {
  Collection,
  MapEdit,
  MapTheme,
  Plotting,
}

// 该目录下的数据会被创建在 '/iTablet/'下，不要轻易加
const RelativePath = {
  // 对应用户中的相对路径
  Environment: 'Environment/',
  License: 'License/',
  Log: 'Log/',
  ExternalData: 'ExternalData/',
  Data: Data,
  Datasource: Data + 'Datasource/',
  Scene: Data + 'Scene/',
  Template: Data + 'Template/',
  Symbol: Data + 'Symbol/',
  Attribute: Data + 'Attribute/',
  Workspace: Data + 'Workspace/',
  Map: Data + 'Map/',
  Color: Data + 'Color/',
  Temp: Data + 'Temp/', // 临时文件
  Label: Data + 'Label/', // 标注
}

const RelativeFilePath = {
  ExportData: 'ExportData/',
  ExternalData: 'ExternalData',
  WorkspaceFile: Workspace,
  // Workspace: Data + 'Workspace.smwu', // 工作空间
  DefaultData: DefaultData, // 默认数据文件夹目录
  DefaultWorkspaceDir: DefaultData + 'Workspace/', // 工作空间默认数据文件夹目录
  Workspace: DefaultData + 'Workspace/Workspace.sxwu', // 工作空间
  Scene: Data + 'Scene/',
  List: Data + 'Scene/List/',
  Map: Data + 'Map/',
  Color: Data + 'Color/',
  Collection: Data + 'Map/' + Collection + '/',
  MapEdit: Data + 'Map/' + MapEdit + '/',
  MapTheme: Data + 'Map/' + MapTheme + '/',
}

// 默认创建的目录
export default {
  AppPath,
  // SampleDataPath: AppPath + 'data/sample/', // 存放示例数据
  // LocalDataPath: AppPath + 'data/local/', // 存放用户地图数据
  // UserPath: AppPath + '/user/', // 存放用户数据
  LicensePath: AppPath + 'license/', // 存放许可文件
  // Audio: AppPath + 'audio/', // 存放语音

  CachePath: AppPath + 'Cache/',
  CachePath2: AppPath + 'Cache',
  // SampleDataPath: AppPath + '/SampleData/', // 存放示例数据
  UserPath: AppPath + 'User/', // 存放用户数据
  UserPath2: AppPath + 'User', // 存放用户数据
  Common: AppPath + 'Common/', // 公共数据
  Import: AppPath + 'Import', //导入外部数据文件夹
  // 游客目录
  CustomerPath: AppPath + 'User/Customer/', // 存放游客数据
  RelativePath,
  RelativeFilePath,
  Module,
}
