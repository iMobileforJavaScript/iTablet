export default {
  UN_CHECK: 0,
  CHECKED: 1,
  UN_CHECK_DISABLE: 2,
  CHECKED_DISABLE: 3,
}
