const DARK_THEME = 'darkTheme'
const LIGHT_THEME = 'lightTheme'

export default { DARK_THEME, LIGHT_THEME }
